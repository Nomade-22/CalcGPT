# Multprest GPT Site

Site estático para rodar no GitHub Pages, com integração futura a um backend seguro (Render).

## Estrutura
- `index.html` → Página principal
- `style.css` → Estilos (tema escuro)
- `script.js` → Lógica do chat (faz chamada ao backend)
- `README.md` → Instruções

## Como usar
1. Suba essa pasta no seu repositório do GitHub.
2. Ative o GitHub Pages (branch main, pasta `/`).
3. O chat ainda não funcionará até configurarmos o backend no Render (Parte 2).
